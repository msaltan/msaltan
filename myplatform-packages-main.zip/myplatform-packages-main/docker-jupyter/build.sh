#!/usr/bin/env bash
# Builds the jupyter-fs/s3fs/Trino derivative images used by the jupyterhub
# package's profileList (packages/services/jupyterhub/jupyterhub.yaml).
#
# Usage:
#   ./build.sh            # build all flavors, tag locally, don't push
#   ./build.sh --push      # build all flavors and push to REGISTRY
#
# Env overrides:
#   REGISTRY   default: quay.io/aidos/images
#   TAG_SUFFIX default: -fs1   (bump this if you change the Dockerfile's package set/versions)

set -euo pipefail

REGISTRY="${REGISTRY:-quay.io/aidos/images}"
TAG_SUFFIX="${TAG_SUFFIX:--fs1}"
PUSH=false
[[ "${1:-}" == "--push" ]] && PUSH=true

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# name | base image
FLAVORS=(
  "jupyter-minimal-notebook|quay.io/jupyter/minimal-notebook:2026-09-01"
  "jupyter-scipy-notebook|quay.io/jupyter/scipy-notebook:2026-09-01"
  "jupyter-datascience-notebook|quay.io/jupyter/datascience-notebook:2026-09-01"
  "jupyter-all-spark-notebook|quay.io/jupyter/all-spark-notebook:spark-4.1.2"
)

for entry in "${FLAVORS[@]}"; do
  name="${entry%%|*}"
  base_image="${entry#*|}"
  base_tag="${base_image##*:}"
  target="${REGISTRY}/${name}:${base_tag}${TAG_SUFFIX}"

  echo "== building ${target} (from ${base_image}) =="
  docker build \
    -f "${SCRIPT_DIR}/Dockerfile" \
    --build-arg "BASE_IMAGE=${base_image}" \
    -t "${target}" \
    "${SCRIPT_DIR}"

  if [[ "${PUSH}" == "true" ]]; then
    echo "== pushing ${target} =="
    docker push "${target}"
  fi
done

# Companion executor image for SPARK_EXECUTOR_IMAGE - same Iceberg version/build as
# whatever iceberg-spark-runtime the notebook Dockerfile added for the spark flavor above.
executor_base="apache/spark:4.1.2-scala2.13-java21-python3-ubuntu"
executor_target="${REGISTRY}/spark-executor:4.1.2-iceberg-1.11.0-2"

echo "== building ${executor_target} (from ${executor_base}) =="
docker build \
  -f "${SCRIPT_DIR}/Dockerfile.spark-executor" \
  --build-arg "BASE_IMAGE=${executor_base}" \
  --build-arg "SPARK_VERSION=4.1" \
  --build-arg "SCALA_VERSION=2.13" \
  -t "${executor_target}" \
  "${SCRIPT_DIR}"

if [[ "${PUSH}" == "true" ]]; then
  echo "== pushing ${executor_target} =="
  docker push "${executor_target}"
fi

# History server companion image - Hadoop S3A connector + the jakarta-classified
# aidos auth filter (Spark 4.x's embedded Jetty moved off javax.servlet), used by
# packages/services/spark-history-server/spark-history-server.yaml.
history_server_base="apache/spark:4.1.2-scala2.13-java21-ubuntu"
history_server_target="${REGISTRY}/spark-history-server:4.1.2-auth1.4.4"

echo "== building ${history_server_target} (from ${history_server_base}) =="
docker build \
  -f "${SCRIPT_DIR}/Dockerfile.spark-history-server" \
  --build-arg "BASE_IMAGE=${history_server_base}" \
  -t "${history_server_target}" \
  "${SCRIPT_DIR}"

if [[ "${PUSH}" == "true" ]]; then
  echo "== pushing ${history_server_target} =="
  docker push "${history_server_target}"
fi

if [[ "${PUSH}" == "false" ]]; then
  echo
  echo "Built locally only. Re-run with --push to push to ${REGISTRY}."
fi
