#!/usr/bin/env bash
#
# Packages every unpacked chart directory under charts/ (charts/<name>/Chart.yaml)
# back into a .tgz using `helm package`, writing the result into charts/ so it
# can be pushed with publish-charts.sh.
#
# Skips charts/backup (where the originally downloaded .tgz files live).
#
# Usage:
#   ./package-charts.sh                  # package every chart dir under ../../charts
#   ./package-charts.sh cert-manager     # package only chart dir(s) named "cert-manager"
#   ./package-charts.sh cert-manager trino
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CHARTS_DIR="${SCRIPT_DIR}/../../charts"

FILTER=("$@")

matches_filter() {
  local name="$1"
  [[ ${#FILTER[@]} -eq 0 ]] && return 0
  for f in "${FILTER[@]}"; do
    [[ "$name" == "$f" ]] && return 0
  done
  return 1
}

ok=0
fail=0
failed_names=()

for dir in "$CHARTS_DIR"/*/; do
  name="$(basename "$dir")"
  [[ "$name" == "backup" ]] && continue
  [[ -f "$dir/Chart.yaml" ]] || continue
  matches_filter "$name" || continue

  echo "==> packaging $name"
  if helm package "$dir" -d "$CHARTS_DIR"; then
    ok=$((ok+1))
  else
    echo "    FAILED"
    fail=$((fail+1))
    failed_names+=("$name")
  fi
done

echo ""
echo "Done. $ok succeeded, $fail failed."
if [[ $fail -gt 0 ]]; then
  printf 'Failed: %s\n' "${failed_names[@]}"
  exit 1
fi
