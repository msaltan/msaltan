#!/usr/bin/env bash
#
# Publishes every downloaded chart (charts/*.tgz) to your own quay.io registry
# under: quay.io/aidos/ie-sandbox-dependencies/charts/<chart-name>:<version>
#
# Prerequisites:
#   - Charts already downloaded via ./download-charts.sh
#   - Logged in to quay.io with push rights:
#       helm registry login quay.io -u <your-quay-user> -p <your-quay-token>
#
# Usage:
#   ./publish-charts.sh                  # publish every .tgz in ../../charts
#   ./publish-charts.sh cert-manager      # publish only chart(s) whose filename starts with "cert-manager-"
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CHARTS_DIR="${SCRIPT_DIR}/../../charts"
DEST="oci://quay.io/aidos/ie-sandbox-dependencies/charts"

FILTER=("$@")

matches_filter() {
  local fname="$1"
  [[ ${#FILTER[@]} -eq 0 ]] && return 0
  for f in "${FILTER[@]}"; do
    [[ "$fname" == "$f"-* ]] && return 0
  done
  return 1
}

shopt -s nullglob
files=("$CHARTS_DIR"/*.tgz)
shopt -u nullglob

if [[ ${#files[@]} -eq 0 ]]; then
  echo "No .tgz files found in $CHARTS_DIR - run download-charts.sh first."
  exit 1
fi

ok=0
fail=0
failed_names=()

for f in "${files[@]}"; do
  base="$(basename "$f")"
  matches_filter "$base" || continue

  echo "==> pushing $base -> $DEST"
  if helm push "$f" "$DEST"; then
    ok=$((ok+1))
  else
    echo "    FAILED"
    fail=$((fail+1))
    failed_names+=("$base")
  fi
done

echo ""
echo "Done. $ok succeeded, $fail failed."
if [[ $fail -gt 0 ]]; then
  printf 'Failed: %s\n' "${failed_names[@]}"
  exit 1
fi
