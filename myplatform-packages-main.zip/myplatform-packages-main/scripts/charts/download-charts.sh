#!/usr/bin/env bash
#
# Downloads every Helm chart listed in charts-manifest.csv into ../../charts/
# as a .tgz package, ready to be re-published with publish-charts.sh.
#
# Usage:
#   ./download-charts.sh                 # download everything in the manifest
#   ./download-charts.sh cert-manager     # download only the chart(s) named "cert-manager"
#   ./download-charts.sh cert-manager trino
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MANIFEST="${SCRIPT_DIR}/charts-manifest.csv"
DEST_DIR="${SCRIPT_DIR}/../../charts"

FILTER=("$@")

mkdir -p "$DEST_DIR"

matches_filter() {
  local name="$1"
  [[ ${#FILTER[@]} -eq 0 ]] && return 0
  for f in "${FILTER[@]}"; do
    [[ "$name" == "$f" ]] && return 0
  done
  return 1
}

ok=0
fail=0
failed_names=()

while IFS=, read -r type name source chart version; do
  [[ -z "$type" || "$type" == \#* ]] && continue
  matches_filter "$name" || continue

  echo "==> [$type] $name:$version"
  target="${DEST_DIR}/${name}-${version}.tgz"
  if [[ -f "$target" ]]; then
    echo "    already downloaded -> $target (skipping)"
    ok=$((ok+1))
    continue
  fi

  if [[ "$type" == "oci" ]]; then
    if helm pull "oci://${source}" --version "$version" -d "$DEST_DIR"; then
      ok=$((ok+1))
    else
      echo "    FAILED"
      fail=$((fail+1))
      failed_names+=("$name")
    fi
  elif [[ "$type" == "helm" ]]; then
    if helm pull "$chart" --repo "$source" --version "$version" -d "$DEST_DIR"; then
      ok=$((ok+1))
    else
      echo "    FAILED"
      fail=$((fail+1))
      failed_names+=("$name")
    fi
  else
    echo "    unknown type '$type', skipping"
  fi
done < "$MANIFEST"

echo ""
echo "Done. $ok succeeded, $fail failed."
if [[ $fail -gt 0 ]]; then
  printf 'Failed: %s\n' "${failed_names[@]}"
  exit 1
fi
