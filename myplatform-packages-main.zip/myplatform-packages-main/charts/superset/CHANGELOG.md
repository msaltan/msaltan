# Changelog

## [0.15.2-2.0](https://github.com/ai-dos-tr/aidos-superset/compare/helm-aidos-superset/v0.15.2-1.0...helm-aidos-superset/v0.15.2-2.0) (2026-04-10)


### chore

* release 0.15.2-2.0 ([2dde524](https://github.com/ai-dos-tr/aidos-superset/commit/2dde524de81aef6e5a9a58b3ea46c7c43908c8d0))


### Features

* add OAuth2 support for Trino ([fe4e46b](https://github.com/ai-dos-tr/aidos-superset/commit/fe4e46b6af05bb5c602b9b6a227d0f7426e4167d))

## [0.15.2-1.0](https://github.com/ai-dos-tr/aidos-superset/compare/helm-aidos-superset/v0.15.0-1.1...helm-aidos-superset/v0.15.2-1.0) (2026-04-07)


### chore

* release 0.15.2-1.0 ([e9038f5](https://github.com/ai-dos-tr/aidos-superset/commit/e9038f5f8602fa22d1a1a83d502c9a98a7b9d7ce))
* release 6.0.0-1.0 ([83e934b](https://github.com/ai-dos-tr/aidos-superset/commit/83e934b1bd6892a74e3bfd99f93c624ec0779008))

## [0.15.0-1.1](https://github.com/ai-dos-tr/aidos-superset/compare/helm-aidos-superset/v0.15.0-1.0...helm-aidos-superset/v0.15.0-1.1) (2025-11-24)


### chore

* release 0.15.0-1.1 ([58f636f](https://github.com/ai-dos-tr/aidos-superset/commit/58f636fb1278a118217c6d6701640bf68bc09aa5))


### Bug Fixes

* fix supoort for external secrets (optional) ([bb04ce7](https://github.com/ai-dos-tr/aidos-superset/commit/bb04ce7a70d7a2dfdb5aaca9e769a0051a6a729d))
* remove Authlib and sqlalchemy-trino from Helm values (already bundled in the image) ([a96d99e](https://github.com/ai-dos-tr/aidos-superset/commit/a96d99ef8d9a7ef85fe1ce81e5684ae222c3911d))

## [0.15.0-1.0](https://github.com/ai-dos-tr/aidos-superset/compare/helm-aidos-superset/v0.12.10-1.0...helm-aidos-superset/v0.15.0-1.0) (2025-10-15)


### chore

* release 0.15.0-1.0 ([e6274ea](https://github.com/ai-dos-tr/aidos-superset/commit/e6274ea3003827df420079e50ae030acd1e71767))
* release 5.0.0-1.0 ([c085e40](https://github.com/ai-dos-tr/aidos-superset/commit/c085e4023e31ca6cabc5296b34deffff131fb80b))


### Features

* upgrade to superset 5.0.0 ([0c53642](https://github.com/ai-dos-tr/aidos-superset/commit/0c536422bda70848679cb9c2f21fea5e2b185ceb))

## 0.12.10-1.0 (2025-10-14)


### chore

* release 0.12.10-1.0 ([05deca8](https://github.com/ai-dos-tr/aidos-superset/commit/05deca839c5212739b0b0dd219c9d22e40c24d90))
* release 0.12.10-1.0 ([ac8ddc7](https://github.com/ai-dos-tr/aidos-superset/commit/ac8ddc7c52d071b382eae897b6e9e69eadc34048))
* release 0.12.10-1.0.0 ([54afd6c](https://github.com/ai-dos-tr/aidos-superset/commit/54afd6c19c373bf301efbec3fa05f30904033ed0))


### Features

* **superset:** Official superset helm chart repackaging through a meta-chart ([5a3f345](https://github.com/ai-dos-tr/aidos-superset/commit/5a3f34519a53737f98846e20c4235f0ae14f7874))
* **superset:** Provide sample values ([4453eae](https://github.com/ai-dos-tr/aidos-superset/commit/4453eae1e3d4804f442fcdeb6a4ada27757024f9))


### Bug Fixes

* add support for dockerize and websocket superset images ([01cbaa4](https://github.com/ai-dos-tr/aidos-superset/commit/01cbaa450d40c6ac3e848942ae0c25a84045fa8f))

## 0.12.10-1.0.0 (2025-10-14)


### chore

* release 0.12.10-1.0.0 ([54afd6c](https://github.com/ai-dos-tr/aidos-superset/commit/54afd6c19c373bf301efbec3fa05f30904033ed0))


### Features

* **superset:** Official superset helm chart repackaging through a meta-chart ([5a3f345](https://github.com/ai-dos-tr/aidos-superset/commit/5a3f34519a53737f98846e20c4235f0ae14f7874))
* **superset:** Provide sample values ([4453eae](https://github.com/ai-dos-tr/aidos-superset/commit/4453eae1e3d4804f442fcdeb6a4ada27757024f9))


### Bug Fixes

* add support for dockerize and websocket superset images ([01cbaa4](https://github.com/ai-dos-tr/aidos-superset/commit/01cbaa450d40c6ac3e848942ae0c25a84045fa8f))
