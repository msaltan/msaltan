# Changelog

## [0.4.1](https://github.com/ai-dos-tr/aidos-ui/compare/helm-aidos-ui/v0.3.0...helm-aidos-ui/v0.4.1) (2025-12-17)


### Bug Fixes

* **nginx:** drop IPv6 nginx from config ([b0056f0](https://github.com/ai-dos-tr/aidos-ui/commit/b0056f094b7a6bb4691d91ac4eac7e280d368d2f))


### Continuous Integration

* release 0.4.1 ([a4a1a49](https://github.com/ai-dos-tr/aidos-ui/commit/a4a1a495c28321b0ea66977f1c6499dea7f00bf3))

## [0.3.0](https://github.com/ai-dos-tr/aidos-ui/compare/helm-aidos-ui/v0.2.0...helm-aidos-ui/v0.3.0) (2025-07-10)


### Refactoring

* add helm versioning ([85c2aaa](https://github.com/ai-dos-tr/aidos-ui/commit/85c2aaa8d7223aa65d0a64dc28a7fbcc4afae8a0))


### Continuous Integration

* release 0.3.0 ([fd4be4f](https://github.com/ai-dos-tr/aidos-ui/commit/fd4be4f5332089f42fcd77e3585c685160b622d7))

## [0.2.0](https://github.com/ai-dos-tr/aidos-ui/compare/helm-aidos-ui/v0.1.0...helm-aidos-ui/v0.2.0) (2025-07-10)


### Features

* **config:** add support for 'git' and 'kubernetes' submission modes ([7784f26](https://github.com/ai-dos-tr/aidos-ui/commit/7784f2687872cb9c149c5650d8bf669bf7c7d8b3))


### Bug Fixes

* resolve SPA routing 404 errors on page refresh by adding nginx try_files configuration ([7890034](https://github.com/ai-dos-tr/aidos-ui/commit/7890034a693d4b5532705bd6026c2141f24d7bb2))


### Refactoring

* KuboCD integration - deploy and list KuboCD releases ([173a6ac](https://github.com/ai-dos-tr/aidos-ui/commit/173a6aca77955ee35ecf27357a179147570a61b0))

## 0.1.0 (2025-04-03)


### Features

* **helm:** add initial Helm chart ([2fe746d](https://github.com/ai-dos-tr/aidos-ui/commit/2fe746ddaa455c725ff1f5b51c53bb22b3f9bfd4))
