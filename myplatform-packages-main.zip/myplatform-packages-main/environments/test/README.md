# Test environment

A copy of the root context files, `kubocd.yaml`, and `releases/`, with the platform's own
ingress domain changed from the real prod domain (`iett.gov.tr`) to a test-only domain
(`iettaidos.sandbox`) — matching what this repo used before commit `72977a7` ("Migrate
platform domain from iettaidos.sandbox to iett.gov.tr").

This directory only contains files — nothing here has been applied to any cluster. Root's
files (and whatever your current live cluster is actually running) are untouched.

## What changed vs. root

Every platform-service ingress hostname (`10-platform-context.yaml`'s `ingress.suffix`,
SeaweedFS/Keycloak endpoints in `20-provider-context.yaml`, every service `url`/`uri` in
`30-service-context.yaml` and `99-examples-context.yaml`, and the wildcard cert `commonName`
in `releases/cert-manager.yaml`) now uses `iettaidos.sandbox` instead of `iett.gov.tr`.

## What deliberately did NOT change

Per your instruction to keep this bound to the same real AD:

- `ldapFederation.connectionUrl: ldap://dc.iett.gov.tr:389` — the real AD domain controller's
  actual hostname. This is a separate real network endpoint, not a platform-ingress hostname,
  so it doesn't follow the `iettaidos.sandbox` swap.
- `usersDn: OU=Kullanicilar,DC=iett,DC=yerel` and `bindDn: kmsuser@iett.yerel` — the real AD's
  own internal domain components, unrelated to the platform's ingress suffix.
- `storageClass.data`/`workspace` (still `local-path`) and `portal.clusters` (still
  `id: sandbox` / `env: dev`) — these already correctly describe a test/sandbox cluster in
  root, so nothing needed changing here (unlike `environments/prod`, where those were
  deliberately turned into placeholders for a genuinely new cluster).

## Fake DNS: dns-server + coredns-patch

`iettaidos.sandbox` isn't a real registrable domain, so unlike prod's `iett.gov.tr` there's no
real DNS to resolve it. `releases/dns-server.yaml` and `releases/coredns-patch.yaml` (copied
from the repo's `releases_fake/`) are included here for exactly that: dns-server runs a small
in-cluster `dnsmasq` that resolves the ingress domain to the ingress controller, and
coredns-patch points CoreDNS at it so in-cluster DNS resolves `*.iettaidos.sandbox` without any
real external DNS record.

Both packages (`packages/system_fake/dns-server`, `packages/system_fake/coredns-patch`) had a
real bug fixed as part of this: they hardcoded `iett.gov.tr` literally in their Helm values even
though each one's own schema already declared `platform.ingress.suffix` as a required context
input - so today, before this fix, they'd always have redirected `*.iett.gov.tr` regardless of
what the actual platform context said. Both now read `.Context.platform.ingress.suffix`
directly, so they follow whatever domain the environment they're deployed into actually uses.
This fix is shared (not test-only) - it applies wherever these packages are ever used.
`coredns-patch` also gained an explicit `dependencies: [ingress]` (it patches CoreDNS to route
to ingress-nginx's Service by name, so it needs to exist first).

Per `docs/production-deployment.md`, these two releases should stay out of `environments/prod`
- prod's real domain has real DNS, and a fake in-cluster resolver would only fight it.

**Note:** rendering these packages against your actual live test cluster (read-only, via
`kubocd render`) showed its current `platform.ingress.suffix` is `okdp.sandbox` - not
`iettaidos.sandbox` (this directory) or `iett.gov.tr` (root). You confirmed `iettaidos.sandbox`
is what this directory should standardize on regardless; the live cluster would need its
Context updated separately (not done here - see "Files only for now" from earlier) to actually
match what's in this directory.

## Relationship to environments/prod

- `environments/prod/` = real prod values (`iett.gov.tr`, real AD, self-signed TLS as decided
  earlier) with storage class/cluster-label placeholders for a not-yet-provisioned cluster.
- `environments/test/` = this directory: same real AD, test-only ingress domain.
- Root = currently identical to `environments/prod` in content (same `iett.gov.tr` domain, same
  AD wiring) but still labeled `id: sandbox` / `env: dev` in its own portal metadata — that
  mismatch is pre-existing and untouched; nothing here modifies root.
