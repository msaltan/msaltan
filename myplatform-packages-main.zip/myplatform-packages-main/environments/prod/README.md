# Prod environment (clean install, staged)

This directory is a self-contained copy of the root context files, `kubocd.yaml`, and
`releases/`, adapted for a from-scratch production install on a **cluster that does not exist
yet** (per your answers: prep the files now, self-signed TLS with a placeholder domain, keep
the Keycloak-local demo realm/users rather than wiring real AD/LDAP yet).

It does not modify anything in the repo root — the sandbox/test environment you've been
rendering against is untouched.

## What's already resolved

- **Secrets**: inherits the `local-secrets-provider` fix from `packages/system/local-secrets-provider/local-secrets-provider.yaml` (Phase 1) - most credentials auto-generate in-cluster via the `secret-generator` controller (already part of the `tools` package/release). The `TODO(secrets-phase2)` values in that file (OIDC client secrets duplicated into Keycloak's realm-import, Airflow's Fernet key, JupyterHub's crypt key) are still hardcoded platform-wide, sandbox and prod alike, pending that follow-up.
- **TLS**: kept self-signed (`certificateIssuers.selfSigned`), per your choice. `releases/cert-manager.yaml`'s wildcard cert `commonName` now matches the placeholder domain below.
- **Identity**: `ldapFederation.enabled: false` in `99-examples-context.yaml` - Keycloak keeps its local demo realm/users. The customer-specific AD details that were live in the test env's `99-examples-context.yaml` (real hostname, DN, bind account) were **not** copied here - only inert placeholders, so this can't accidentally point at anyone's real AD. When you do wire AD later, follow `docs/production-deployment.md` §3, not the test env's block.
- **Domain**: every `iett.gov.tr` literal across the 4 context files and `releases/cert-manager.yaml` (29+ occurrences - there is no single "suffix" variable these derive from, contrary to what `docs/production-deployment.md` §1 implies; every occurrence had to be replaced individually) is now `prod.example.com`, an RFC 2606 placeholder.

## What you must still fill in (grep for these before applying)

```
grep -rn "REPLACE_WITH\|prod.example.com" environments/prod/
```

1. **`prod.example.com`** → your real domain, everywhere it appears (`10-platform-context.yaml`, `20-provider-context.yaml`, `30-service-context.yaml`, `99-examples-context.yaml`, `releases/cert-manager.yaml`). Get a wildcard DNS record (or per-service A/CNAME records) pointed at your ingress-nginx LoadBalancer IP.
2. **`storageClass.data` / `storageClass.workspace`** in `10-platform-context.yaml` → a real StorageClass name that exists on the target cluster (affects JupyterHub's and SeaweedFS's PVCs specifically - `cnpg-postgresql`'s Postgres storage is already overridden separately in `releases/cnpg-postgresql.yaml` with `storageClass: standard`, confirm that name exists too).
3. **`environments/prod/kubocd.yaml`**: unchanged from root - review `controller.replicaCount: 1` / `logger.mode: dev` / `metrics.enabled: false` before going live; this is the GitOps control plane for everything else.

## Deliberately left as-is (not asked to change, flagging so it's a conscious choice)

- **`packageRepository: quay.io/aidos/ie-sandbox-dependencies`** and every `releases/*.yaml`'s `repository:` field still point at the same registry the test env publishes to. Functionally fine (same packages, same versions) but the name literally says "sandbox" - decide later whether prod should publish to its own registry path.
- **`ingress-nginx` `mode: hostPort`** (`releases/ingress-nginx.yaml`) - fine for bare-metal/on-prem, wrong if the target cluster has a cloud LoadBalancer.
- Everything from the broader production-readiness review that isn't domain/TLS/identity (no backup wiring, no HA on the KuboCD controller, `kubernetes-secret-generator`'s per-key format limits, etc.) - unchanged, still applies here exactly as discussed for the test env.

## Bootstrap order (once a cluster exists)

1. Install Flux on the target cluster.
2. `kubectl apply -f environments/prod/kubocd.yaml` - bootstraps the KuboCD controller.
3. Apply contexts in order: `10-platform-context.yaml`, `20-provider-context.yaml`, `30-service-context.yaml`, `99-examples-context.yaml`.
4. `kubectl apply -f environments/prod/releases/` - brings up the system/bootstrap layer (cert-manager, ingress-nginx, Keycloak, CloudNativePG, etc.). Note only the bootstrap layer has Release manifests today - the data-platform services (Superset, Trino, Polaris, etc.) aren't in `releases/` in this repo at all; confirm whether those get deployed via the self-service portal or need their own Release manifests added here too.
5. Wait for all `Release` resources to report `READY` (same check `ci.yml` does for the test env).
