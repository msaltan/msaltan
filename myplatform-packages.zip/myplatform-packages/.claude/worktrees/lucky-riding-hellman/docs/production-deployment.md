# Production Deployment Guide

Guidance for adapting this repo (built around the `iettaidos.sandbox` demo environment)
to a real deployment where:

- the customer has their own public/internal **domain**
- the Kubernetes **nodes** sit on the company's own internal domain (unrelated to the above — see note at the end)
- the company has its own **Active Directory / LDAP**
- TLS is issued from the company's own internal **CA**

This is a template to copy into the target repo/cluster — it does not modify the
sandbox context files in this repo.

## 1. Domain (`10-platform-context.yaml` equivalent)

```yaml
platform:
  ingress:
    suffix: data.customer.com      # customer's real domain
    className: nginx
  certificateIssuers:
    selfSigned:
      name: company-ca-issuer      # renamed conceptually; see §2
```

Every service URL in `30-service-context.yaml` is templated as
`https://<svc>-{{ .Release.namespace }}.{{ suffix }}`, so changing this one value
re-derives every hostname (e.g. `okdp-ui-default.data.customer.com`).

Ask the customer for a **wildcard DNS record** (`*.data.customer.com` → your
ingress-nginx LoadBalancer IP), or individual A/CNAME records per service if they
won't do wildcards.

**Drop these two releases** — they only exist to fake DNS resolution for the
fictitious `iettaidos.sandbox` domain inside the cluster, and will actively fight real
DNS resolution:
- `releases/dns-server.yaml`
- `releases/coredns-patch.yaml`

## 2. TLS via the company's internal CA

The cert-manager package already supports a CA-backed issuer, not just
self-signed — see `packages/system/cert-manager/cert-manager.yaml` schema
(`issuers.caClusterIssuers`). In the target repo's `releases/cert-manager.yaml`:

```yaml
parameters:
  issuers:
    enabled: true
    caClusterIssuers:
      - name: company-ca-issuer
        ca_crt: "<BASE64_CA_CERT_FROM_YOUR_PKI_TEAM>"
        ca_key: "<INJECT_AT_APPLY_TIME_NEVER_COMMIT>"
```

**Do not commit `ca_key` to git as plaintext**, even encrypted-at-rest — the
upstream chart's own `values.yaml` explicitly warns about this ("Including
private keys in values is a security risk"). Two real options:

- If your Flux setup uses SOPS, encrypt just this one Release manifest.
- Better: apply this specific Release object via your CI/CD secrets pipeline
  (not the GitOps sync path), so the private key never lands in git history at all.

Also set `trust.enabled: true` (already the default shape) so the company CA
cert gets distributed cluster-wide via trust-manager — otherwise in-cluster
TLS/OIDC validation between services (Trino → Keycloak, Airflow → Keycloak, etc.)
will fail against a CA nothing trusts by default.

## 3. Active Directory via LDAPS — dedicated realm, not `master`

### a) New realm name

Use a dedicated realm, e.g. `okdp`, instead of reusing `master` (which is meant
for Keycloak's own admin console, not application users). Update the realm
JSON's `"realm"` field, and point the provider context at it:

```yaml
# 20-provider-context.yaml equivalent
defaultIdp:
  provider:
    issuerUri: "https://keycloak.data.customer.com/realms/okdp"
    baseUri: "https://keycloak.data.customer.com/realms/okdp/protocol/openid-connect"
    endpoints:
      authUrl: "https://keycloak.data.customer.com/realms/okdp/protocol/openid-connect/auth"
      tokenUrl: "https://keycloak.data.customer.com/realms/okdp/protocol/openid-connect/token"
      userinfoUrl: "https://keycloak.data.customer.com/realms/okdp/protocol/openid-connect/userinfo"
      jwksUri: "https://keycloak.data.customer.com/realms/okdp/protocol/openid-connect/certs"
```

Nothing else in `30-service-context.yaml` needs to change — every service only
ever consumes `defaultIdp`'s endpoints, never hardcodes `master`.

### b) Add an LDAP User Federation to the realm JSON

Alongside the existing `clients`/`roles` blocks:

```json
"components": {
  "org.keycloak.storage.UserStorageProvider": [
    {
      "name": "company-ad",
      "providerId": "ldap",
      "config": {
        "enabled": ["true"],
        "vendor": ["ad"],
        "connectionUrl": ["ldaps://ad.company.internal:636"],
        "usersDn": ["OU=Users,DC=company,DC=internal"],
        "authType": ["simple"],
        "bindDn": ["CN=svc-keycloak-bind,OU=ServiceAccounts,DC=company,DC=internal"],
        "bindCredential": ["$(env:LDAP_BIND_PASSWORD)"],
        "usernameLDAPAttribute": ["sAMAccountName"],
        "rdnLDAPAttribute": ["cn"],
        "uuidLDAPAttribute": ["objectGUID"],
        "userObjectClasses": ["person, organizationalPerson, user"],
        "useTruststoreSpi": ["ldapsOnly"],
        "editMode": ["READ_ONLY"],
        "importEnabled": ["true"],
        "pagination": ["true"]
      },
      "subComponents": {
        "org.keycloak.storage.ldap.mappers.LDAPStorageMapper": [
          {
            "name": "ad-role-mapper",
            "providerId": "role-ldap-mapper",
            "config": {
              "roles.dn": ["OU=Groups,DC=company,DC=internal"],
              "role.name.ldap.attribute": ["cn"],
              "role.object.classes": ["group"],
              "membership.ldap.attribute": ["member"],
              "membership.attribute.type": ["DN"],
              "use.realm.roles.mapping": ["true"],
              "mode": ["READ_ONLY"]
            }
          }
        ]
      }
    }
  ]
}
```

The bind password uses `$(env:LDAP_BIND_PASSWORD)` — keycloak-config-cli's
variable-substitution feature — resolved from a real `extraEnvVars` entry with
`secretKeyRef`, the same pattern this repo already uses for `KEYCLOAK_PASSWORD`
in `packages/system/keycloak/keycloak.yaml`. So the LDAP bind secret sits in a
normal K8s Secret (ideally populated by `external-secrets` from Vault/whatever
the company uses), never in the realm JSON itself.

> Verify the exact substitution syntax against the `keycloak-config-cli:6.4.0`
> docs before relying on it — it has changed across versions.

**Caveat on the role mapper:** `role-ldap-mapper` maps an AD group to a realm
role only when the AD group's `cn` matches the role name exactly. The existing
realm roles are `data_engineer`, `data_scientist`, `business_analyst`,
`platform_admin`, `data_steward`, `auditor` — either get the company to
name/alias AD groups to match those exactly, or add one `role-ldap-mapper` per
AD-group → role pair with a `roles.dn` scoped to that specific group.

### c) Drop the demo users

Remove `bob`, `mark`, `nina`, `grace`, `alice`, `eve`, `adm` from the `users:`
list — real people now come from AD. Keep the `svc-*` service-account users
(`svc-spark-etl-polaris-writer`, `svc-polaris-api-admin`,
`svc-trino-polaris-writer`) — those are Keycloak-native OAuth2
client-credentials identities for machine-to-machine auth, unrelated to LDAP.

## 4. Secrets management

Swap `releases/local-secrets-provider.yaml` (explicitly "for local testing" per
its own description) for a real `external-secrets` `ClusterSecretStore` /
`SecretStore` backed by the company's actual secret manager (Vault, cloud
secret manager, etc.), and rotate every hardcoded credential currently in this
repo — the `admin`/`admin` Keycloak admin password in `releases/keycloak.yaml`,
and the client `secret` fields in the realm JSON (`mySupersetSecret`,
`myTrinoSecret`, etc.) — to generated values pulled through that store.

## 5. Suggested rollout order

1. DNS + CA issuer first — get `https://keycloak.<domain>` serving on a
   trusted cert.
2. Stand up the new `okdp` realm with LDAP federation *alongside* `master`,
   test login with a real AD user.
3. Repoint `defaultIdp` to the new realm — this is the cutover moment; every
   service's OIDC login breaks until it picks up the new issuer, so batch it
   as one change.
4. Remove demo users / `local-secrets-provider` last, once real users can log
   in and get the right roles.

## Note: node domain vs. customer domain

The Kubernetes nodes' own hostnames being on the company's internal domain
doesn't interact with any of the above — ingress hostnames, cert SANs, and
OIDC issuer URLs are all independent of node FQDNs. The one place it could
matter is corporate proxy egress rules — this repo already has a slot for
that: `platform.proxy.httpProxy` / `httpsProxy` / `noProxy` in
`10-platform-context.yaml`, currently unset. If the company enforces an
outbound proxy, that's where the internal domain and any proxy-bypass ranges
would go.
