# Incident: Keycloak login broken — "Client not found"

**Date:** 2026-08-08
**Symptom:** Logging into `https://aidos-ui.iettaidos.sandbox/login` and clicking
"Login with Keycloak" returned a Keycloak error page: **"Client not found."**

## Root cause

Keycloak's `master` realm holds all the app clients (`okdp-ui`, `okdp-server`,
`trino`, `superset`, ...), users, and roles — but only via a **Helm
post-install/post-upgrade hook Job** (`keycloak-config-cli`), defined in
`packages/system/keycloak/keycloak.yaml`. This hook only runs when Helm
actually performs an install or upgrade.

The last successful Helm upgrade of `keycloak-main` was on 2026-07-05. Nothing
in the chart or values had changed since, so Flux never triggered another
upgrade — and therefore the import hook never ran again. Checking the running
Keycloak directly (via its admin REST API) confirmed the `master` realm only
had the stock default clients/users — none of the custom ones declared in
this repo had ever actually landed.

In short: **the config in git was correct the whole time.** The problem was
purely operational — a one-shot import Job had gone stale.

## Fix applied

```
flux reconcile helmrelease keycloak-main -n kubocd-system --force
```

A plain `flux reconcile` (no `--force`) is a no-op if nothing in the chart or
values changed — it doesn't trigger a real Helm upgrade, so it doesn't re-run
hooks. `--force` makes Flux perform a real upgrade regardless of diff, which
re-ran the `keycloak-config-cli` hook and imported all the clients/users/roles
into `master`. Verified via the admin API afterward — `okdp-ui` and the rest
were present, and login worked.

## Safeguard added

Added a `CronJob` (`keycloak-main-keycloak-config-cli-heal`) as an
`extraDeploy` resource in `packages/system/keycloak/keycloak.yaml`. It reruns
the same `keycloak-config-cli` import every 15 minutes, using the same image,
admin secret, and config ConfigMap as the original hook. `keycloak-config-cli`
is idempotent (create-or-update), so running it repeatedly is safe.

This means if the realm data is ever lost again (e.g. the external Postgres
backing Keycloak gets reset) without a new Helm revision happening, it
self-heals within 15 minutes — no one has to remember to run
`flux reconcile --force` by hand.

**Note:** this change bumped the package tag to `24.4.11-p08` (see
`releases/keycloak.yaml`). It only takes effect once CI builds and publishes
that package version to `quay.io/okdp/platform-packages-v0.3/keycloak` — it
was not live on the cluster as of this writeup.

## The one-line takeaway

> If a Helm-hook-driven import (config-cli, migrations, seed jobs, ...) stops
> reflecting what's in git, check whether Flux/Helm actually re-ran the hook —
> `flux reconcile <kind> <name> --force` forces a real upgrade even when
> nothing changed, which is the only way to make a stale hook fire again.
