package org.apache.flink.streaming.connectors.kafka.table;




public enum KafkaSinkSemantic {
    EXACTLY_ONCE,
    AT_LEAST_ONCE,
    NONE;

    private KafkaSinkSemantic() {
    }
}
