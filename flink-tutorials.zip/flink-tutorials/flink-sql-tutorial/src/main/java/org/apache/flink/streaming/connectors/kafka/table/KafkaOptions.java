//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package org.apache.flink.streaming.connectors.kafka.table;

import java.time.Duration;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.IntStream;
import org.apache.flink.configuration.ConfigOption;
import org.apache.flink.configuration.ConfigOptions;
import org.apache.flink.configuration.ReadableConfig;
import org.apache.flink.streaming.connectors.kafka.config.StartupMode;
import org.apache.flink.streaming.connectors.kafka.internals.KafkaTopicPartition;
import org.apache.flink.streaming.connectors.kafka.partitioner.FlinkFixedPartitioner;
import org.apache.flink.streaming.connectors.kafka.partitioner.FlinkKafkaPartitioner;
import org.apache.flink.table.api.TableException;
import org.apache.flink.table.api.ValidationException;
import org.apache.flink.table.data.RowData;
import org.apache.flink.table.types.DataType;
import org.apache.flink.table.types.logical.LogicalType;
import org.apache.flink.table.types.logical.LogicalTypeRoot;
import org.apache.flink.table.types.logical.utils.LogicalTypeChecks;
import org.apache.flink.util.FlinkException;
import org.apache.flink.util.InstantiationUtil;
import org.apache.flink.util.Preconditions;

public class KafkaOptions {
    public static final ConfigOption<String> KEY_FORMAT = ConfigOptions.key("key.format").stringType().noDefaultValue().withDescription("Defines the format identifier for encoding key data. The identifier is used to discover a suitable format factory.");
    public static final ConfigOption<String> VALUE_FORMAT = ConfigOptions.key("value.format").stringType().noDefaultValue().withDescription("Defines the format identifier for encoding value data. The identifier is used to discover a suitable format factory.");
    public static final ConfigOption<List<String>> KEY_FIELDS = ConfigOptions.key("key.fields").stringType().asList().defaultValues(new String[0]).withDescription("Defines an explicit list of physical columns from the table schema that configure the data type for the key format. By default, this list is empty and thus a key is undefined.");
    public static final ConfigOption<KafkaOptions.ValueFieldsStrategy> VALUE_FIELDS_INCLUDE;
    public static final ConfigOption<String> KEY_FIELDS_PREFIX;
    public static final ConfigOption<List<String>> TOPIC;
    public static final ConfigOption<String> TOPIC_PATTERN;
    public static final ConfigOption<String> PROPS_BOOTSTRAP_SERVERS;
    public static final ConfigOption<String> PROPS_GROUP_ID;
    public static final ConfigOption<String> SCAN_STARTUP_MODE;
    public static final ConfigOption<String> SCAN_STARTUP_SPECIFIC_OFFSETS;
    public static final ConfigOption<Long> SCAN_STARTUP_TIMESTAMP_MILLIS;
    public static final ConfigOption<Duration> SCAN_TOPIC_PARTITION_DISCOVERY;
    public static final ConfigOption<String> SINK_PARTITIONER;
    public static final ConfigOption<String> SINK_SEMANTIC;
    public static final String SCAN_STARTUP_MODE_VALUE_EARLIEST = "earliest-offset";
    public static final String SCAN_STARTUP_MODE_VALUE_LATEST = "latest-offset";
    public static final String SCAN_STARTUP_MODE_VALUE_GROUP_OFFSETS = "group-offsets";
    public static final String SCAN_STARTUP_MODE_VALUE_SPECIFIC_OFFSETS = "specific-offsets";
    public static final String SCAN_STARTUP_MODE_VALUE_TIMESTAMP = "timestamp";
    private static final Set<String> SCAN_STARTUP_MODE_ENUMS;
    public static final String SINK_PARTITIONER_VALUE_DEFAULT = "default";
    public static final String SINK_PARTITIONER_VALUE_FIXED = "fixed";
    public static final String SINK_PARTITIONER_VALUE_ROUND_ROBIN = "round-robin";
    public static final String SINK_SEMANTIC_VALUE_EXACTLY_ONCE = "exactly-once";
    public static final String SINK_SEMANTIC_VALUE_AT_LEAST_ONCE = "at-least-once";
    public static final String SINK_SEMANTIC_VALUE_NONE = "none";
    private static final Set<String> SINK_SEMANTIC_ENUMS;
    public static final String PROPERTIES_PREFIX = "properties.";
    private static final String PARTITION = "partition";
    private static final String OFFSET = "offset";

    private KafkaOptions() {
    }

    public static void validateTableSourceOptions(ReadableConfig tableOptions) {
        validateSourceTopic(tableOptions);
        validateScanStartupMode(tableOptions);
    }

    public static void validateTableSinkOptions(ReadableConfig tableOptions) {
        validateSinkTopic(tableOptions);
        validateSinkPartitioner(tableOptions);
        validateSinkSemantic(tableOptions);
    }

    public static void validateSourceTopic(ReadableConfig tableOptions) {
        Optional<List<String>> topic = tableOptions.getOptional(TOPIC);
        Optional<String> pattern = tableOptions.getOptional(TOPIC_PATTERN);
        if (topic.isPresent() && pattern.isPresent()) {
            throw new ValidationException("Option 'topic' and 'topic-pattern' shouldn't be set together.");
        } else if (!topic.isPresent() && !pattern.isPresent()) {
            throw new ValidationException("Either 'topic' or 'topic-pattern' must be set.");
        }
    }

    public static void validateSinkTopic(ReadableConfig tableOptions) {
        String errorMessageTemp = "Flink Kafka sink currently only supports single topic, but got %s: %s.";
        if (!isSingleTopic(tableOptions)) {
            if (tableOptions.getOptional(TOPIC_PATTERN).isPresent()) {
                throw new ValidationException(String.format(errorMessageTemp, "'topic-pattern'", tableOptions.get(TOPIC_PATTERN)));
            } else {
                throw new ValidationException(String.format(errorMessageTemp, "'topic'", tableOptions.get(TOPIC)));
            }
        }
    }

    private static void validateScanStartupMode(ReadableConfig tableOptions) {
        tableOptions.getOptional(SCAN_STARTUP_MODE).map(String::toLowerCase).ifPresent((mode) -> {
            if (!SCAN_STARTUP_MODE_ENUMS.contains(mode)) {
                throw new ValidationException(String.format("Invalid value for option '%s'. Supported values are %s, but was: %s", SCAN_STARTUP_MODE.key(), "[earliest-offset, latest-offset, group-offsets, specific-offsets, timestamp]", mode));
            } else if (mode.equals("timestamp") && !tableOptions.getOptional(SCAN_STARTUP_TIMESTAMP_MILLIS).isPresent()) {
                throw new ValidationException(String.format("'%s' is required in '%s' startup mode but missing.", SCAN_STARTUP_TIMESTAMP_MILLIS.key(), "timestamp"));
            } else {
                if (mode.equals("specific-offsets")) {
                    if (!tableOptions.getOptional(SCAN_STARTUP_SPECIFIC_OFFSETS).isPresent()) {
                        throw new ValidationException(String.format("'%s' is required in '%s' startup mode but missing.", SCAN_STARTUP_SPECIFIC_OFFSETS.key(), "specific-offsets"));
                    }

                    if (!isSingleTopic(tableOptions)) {
                        throw new ValidationException("Currently Kafka source only supports specific offset for single topic.");
                    }

                    String specificOffsets = (String)tableOptions.get(SCAN_STARTUP_SPECIFIC_OFFSETS);
                    parseSpecificOffsets(specificOffsets, SCAN_STARTUP_SPECIFIC_OFFSETS.key());
                }

            }
        });
    }

    private static void validateSinkPartitioner(ReadableConfig tableOptions) {
        tableOptions.getOptional(SINK_PARTITIONER).ifPresent((partitioner) -> {
            if (partitioner.equals("round-robin") && tableOptions.getOptional(KEY_FIELDS).isPresent()) {
                throw new ValidationException("Currently 'round-robin' partitioner only works when option 'key.fields' is not specified.");
            } else if (partitioner.isEmpty()) {
                throw new ValidationException(String.format("Option '%s' should be a non-empty string.", SINK_PARTITIONER.key()));
            }
        });
    }

    private static void validateSinkSemantic(ReadableConfig tableOptions) {
        tableOptions.getOptional(SINK_SEMANTIC).ifPresent((semantic) -> {
            if (!SINK_SEMANTIC_ENUMS.contains(semantic)) {
                throw new ValidationException(String.format("Unsupported value '%s' for '%s'. Supported values are ['at-least-once', 'exactly-once', 'none'].", semantic, SINK_SEMANTIC.key()));
            }
        });
    }

    public static KafkaSinkSemantic getSinkSemantic(ReadableConfig tableOptions) {
        String var1 = (String)tableOptions.get(SINK_SEMANTIC);
        byte var2 = -1;
        switch(var1.hashCode()) {
            case -286864670:
                if (var1.equals("exactly-once")) {
                    var2 = 0;
                }
                break;
            case 3387192:
                if (var1.equals("none")) {
                    var2 = 2;
                }
                break;
            case 2125618495:
                if (var1.equals("at-least-once")) {
                    var2 = 1;
                }
        }

        switch(var2) {
            case 0:
                return KafkaSinkSemantic.EXACTLY_ONCE;
            case 1:
                return KafkaSinkSemantic.AT_LEAST_ONCE;
            case 2:
                return KafkaSinkSemantic.NONE;
            default:
                throw new TableException("Validator should have checked that");
        }
    }

    public static List<String> getSourceTopics(ReadableConfig tableOptions) {
        return (List)tableOptions.getOptional(TOPIC).orElse(null);
    }

    public static Pattern getSourceTopicPattern(ReadableConfig tableOptions) {
        return (Pattern)tableOptions.getOptional(TOPIC_PATTERN).map(Pattern::compile).orElse(null);
    }

    private static boolean isSingleTopic(ReadableConfig tableOptions) {
        return (Boolean)tableOptions.getOptional(TOPIC).map((t) -> {
            return t.size() == 1;
        }).orElse(false);
    }

    public static KafkaOptions.StartupOptions getStartupOptions(ReadableConfig tableOptions) {
        Map<KafkaTopicPartition, Long> specificOffsets = new HashMap();
        StartupMode startupMode = (StartupMode)tableOptions.getOptional(SCAN_STARTUP_MODE).map((modeString) -> {
            byte var4 = -1;
            switch(modeString.hashCode()) {
                case -1390285235:
                    if (modeString.equals("earliest-offset")) {
                        var4 = 0;
                    }
                    break;
                case -410146651:
                    if (modeString.equals("specific-offsets")) {
                        var4 = 3;
                    }
                    break;
                case 55126294:
                    if (modeString.equals("timestamp")) {
                        var4 = 4;
                    }
                    break;
                case 514263449:
                    if (modeString.equals("latest-offset")) {
                        var4 = 1;
                    }
                    break;
                case 1556617458:
                    if (modeString.equals("group-offsets")) {
                        var4 = 2;
                    }
            }

            switch(var4) {
                case 0:
                    return StartupMode.EARLIEST;
                case 1:
                    return StartupMode.LATEST;
                case 2:
                    return StartupMode.GROUP_OFFSETS;
                case 3:
                    buildSpecificOffsets(tableOptions, (String)((List)tableOptions.get(TOPIC)).get(0), specificOffsets);
                    return StartupMode.SPECIFIC_OFFSETS;
                case 4:
                    return StartupMode.TIMESTAMP;
                default:
                    throw new TableException("Unsupported startup mode. Validator should have checked that.");
            }
        }).orElse(StartupMode.GROUP_OFFSETS);
        KafkaOptions.StartupOptions options = new KafkaOptions.StartupOptions();
        options.startupMode = startupMode;
        options.specificOffsets = specificOffsets;
        if (startupMode == StartupMode.TIMESTAMP) {
            options.startupTimestampMillis = (Long)tableOptions.get(SCAN_STARTUP_TIMESTAMP_MILLIS);
        }

        return options;
    }

    private static void buildSpecificOffsets(ReadableConfig tableOptions, String topic, Map<KafkaTopicPartition, Long> specificOffsets) {
        String specificOffsetsStrOpt = (String)tableOptions.get(SCAN_STARTUP_SPECIFIC_OFFSETS);
        Map<Integer, Long> offsetMap = parseSpecificOffsets(specificOffsetsStrOpt, SCAN_STARTUP_SPECIFIC_OFFSETS.key());
        offsetMap.forEach((partition, offset) -> {
            KafkaTopicPartition topicPartition = new KafkaTopicPartition(topic, partition);
            specificOffsets.put(topicPartition, offset);
        });
    }

    public static Properties getKafkaProperties(Map<String, String> tableOptions) {
        Properties kafkaProperties = new Properties();
        if (hasKafkaClientProperties(tableOptions)) {
            tableOptions.keySet().stream().filter((key) -> {
                return key.startsWith("properties.");
            }).forEach((key) -> {
                String value = (String)tableOptions.get(key);
                String subKey = key.substring("properties.".length());
                kafkaProperties.put(subKey, value);
            });
        }

        return kafkaProperties;
    }

    public static Optional<FlinkKafkaPartitioner<RowData>> getFlinkKafkaPartitioner(ReadableConfig tableOptions, ClassLoader classLoader) {
        return tableOptions.getOptional(SINK_PARTITIONER).flatMap((partitioner) -> {
            byte var3 = -1;
            switch(partitioner.hashCode()) {
                case -1662301013:
                    if (partitioner.equals("round-robin")) {
                        var3 = 2;
                    }
                    break;
                case 97445748:
                    if (partitioner.equals("fixed")) {
                        var3 = 0;
                    }
                    break;
                case 1544803905:
                    if (partitioner.equals("default")) {
                        var3 = 1;
                    }
            }

            switch(var3) {
                case 0:
                    return Optional.of(new FlinkFixedPartitioner());
                case 1:
                case 2:
                    return Optional.empty();
                default:
                    return Optional.of(initializePartitioner(partitioner, classLoader));
            }
        });
    }

    public static Map<Integer, Long> parseSpecificOffsets(String specificOffsetsStr, String optionKey) {
        Map<Integer, Long> offsetMap = new HashMap();
        String[] pairs = specificOffsetsStr.split(";");
        String validationExceptionMessage = String.format("Invalid properties '%s' should follow the format 'partition:0,offset:42;partition:1,offset:300', but is '%s'.", optionKey, specificOffsetsStr);
        if (pairs.length == 0) {
            throw new ValidationException(validationExceptionMessage);
        } else {
            String[] var5 = pairs;
            int var6 = pairs.length;
            int var7 = 0;

            while(var7 < var6) {
                String pair = var5[var7];
                if (null != pair && pair.length() != 0 && pair.contains(",")) {
                    String[] kv = pair.split(",");
                    if (kv.length == 2 && kv[0].startsWith("partition:") && kv[1].startsWith("offset:")) {
                        String partitionValue = kv[0].substring(kv[0].indexOf(":") + 1);
                        String offsetValue = kv[1].substring(kv[1].indexOf(":") + 1);

                        try {
                            Integer partition = Integer.valueOf(partitionValue);
                            Long offset = Long.valueOf(offsetValue);
                            offsetMap.put(partition, offset);
                        } catch (NumberFormatException var14) {
                            throw new ValidationException(validationExceptionMessage, var14);
                        }

                        ++var7;
                        continue;
                    }

                    throw new ValidationException(validationExceptionMessage);
                }

                throw new ValidationException(validationExceptionMessage);
            }

            return offsetMap;
        }
    }

    private static boolean hasKafkaClientProperties(Map<String, String> tableOptions) {
        return tableOptions.keySet().stream().anyMatch((k) -> {
            return k.startsWith("properties.");
        });
    }

    private static <T> FlinkKafkaPartitioner<T> initializePartitioner(String name, ClassLoader classLoader) {
        try {
            Class<?> clazz = Class.forName(name, true, classLoader);
            if (!FlinkKafkaPartitioner.class.isAssignableFrom(clazz)) {
                throw new ValidationException(String.format("Sink partitioner class '%s' should extend from the required class %s", name, FlinkKafkaPartitioner.class.getName()));
            } else {
                FlinkKafkaPartitioner<T> kafkaPartitioner = (FlinkKafkaPartitioner)InstantiationUtil.instantiate(name, FlinkKafkaPartitioner.class, classLoader);
                return kafkaPartitioner;
            }
        } catch (FlinkException | ClassNotFoundException var4) {
            throw new ValidationException(String.format("Could not find and instantiate partitioner class '%s'", name), var4);
        }
    }

    public static int[] createKeyFormatProjection(ReadableConfig options, DataType physicalDataType) {
        LogicalType physicalType = physicalDataType.getLogicalType();
        Preconditions.checkArgument(LogicalTypeChecks.hasRoot(physicalType, LogicalTypeRoot.ROW), "Row data type expected.");
        Optional<String> optionalKeyFormat = options.getOptional(KEY_FORMAT);
        Optional<List<String>> optionalKeyFields = options.getOptional(KEY_FIELDS);
        if (!optionalKeyFormat.isPresent() && optionalKeyFields.isPresent()) {
            throw new ValidationException(String.format("The option '%s' can only be declared if a key format is defined using '%s'.", KEY_FIELDS.key(), KEY_FORMAT.key()));
        } else if (!optionalKeyFormat.isPresent() || optionalKeyFields.isPresent() && ((List)optionalKeyFields.get()).size() != 0) {
            if (!optionalKeyFormat.isPresent()) {
                return new int[0];
            } else {
                String keyPrefix = (String)options.getOptional(KEY_FIELDS_PREFIX).orElse("");
                List<String> keyFields = (List)optionalKeyFields.get();
                List<String> physicalFields = LogicalTypeChecks.getFieldNames(physicalType);
                return keyFields.stream().mapToInt((keyField) -> {
                    int pos = physicalFields.indexOf(keyField);
                    if (pos < 0) {
                        throw new ValidationException(String.format("Could not find the field '%s' in the table schema for usage in the key format. A key field must be a regular, physical column. The following columns can be selected in the '%s' option:\n%s", keyField, KEY_FIELDS.key(), physicalFields));
                    } else if (!keyField.startsWith(keyPrefix)) {
                        throw new ValidationException(String.format("All fields in '%s' must be prefixed with '%s' when option '%s' is set but field '%s' is not prefixed.", KEY_FIELDS.key(), keyPrefix, KEY_FIELDS_PREFIX.key(), keyField));
                    } else {
                        return pos;
                    }
                }).toArray();
            }
        } else {
            throw new ValidationException(String.format("A key format '%s' requires the declaration of one or more of key fields using '%s'.", KEY_FORMAT.key(), KEY_FIELDS.key()));
        }
    }

    public static int[] createValueFormatProjection(ReadableConfig options, DataType physicalDataType) {
        LogicalType physicalType = physicalDataType.getLogicalType();
        Preconditions.checkArgument(LogicalTypeChecks.hasRoot(physicalType, LogicalTypeRoot.ROW), "Row data type expected.");
        int physicalFieldCount = LogicalTypeChecks.getFieldCount(physicalType);
        IntStream physicalFields = IntStream.range(0, physicalFieldCount);
        String keyPrefix = (String)options.getOptional(KEY_FIELDS_PREFIX).orElse("");
        KafkaOptions.ValueFieldsStrategy strategy = (KafkaOptions.ValueFieldsStrategy)options.get(VALUE_FIELDS_INCLUDE);
        if (strategy == KafkaOptions.ValueFieldsStrategy.ALL) {
            if (keyPrefix.length() > 0) {
                throw new ValidationException(String.format("A key prefix is not allowed when option '%s' is set to '%s'. Set it to '%s' instead to avoid field overlaps.", VALUE_FIELDS_INCLUDE.key(), KafkaOptions.ValueFieldsStrategy.ALL, KafkaOptions.ValueFieldsStrategy.EXCEPT_KEY));
            } else {
                return physicalFields.toArray();
            }
        } else if (strategy == KafkaOptions.ValueFieldsStrategy.EXCEPT_KEY) {
            int[] keyProjection = createKeyFormatProjection(options, physicalDataType);
            return physicalFields.filter((pos) -> {
                return IntStream.of(keyProjection).noneMatch((k) -> {
                    return k == pos;
                });
            }).toArray();
        } else {
            throw new TableException("Unknown value fields strategy:" + strategy);
        }
    }

    static {
        VALUE_FIELDS_INCLUDE = ConfigOptions.key("value.fields-include").enumType(KafkaOptions.ValueFieldsStrategy.class).defaultValue(KafkaOptions.ValueFieldsStrategy.ALL).withDescription("Defines a strategy how to deal with key columns in the data type of the value format. By default, '" + KafkaOptions.ValueFieldsStrategy.ALL + "' physical columns of the table schema will be included in the value format which means that key columns appear in the data type for both the key and value format.");
        KEY_FIELDS_PREFIX = ConfigOptions.key("key.fields-prefix").stringType().noDefaultValue().withDescription("Defines a custom prefix for all fields of the key format to avoid name clashes with fields of the value format. By default, the prefix is empty. If a custom prefix is defined, both the table schema and '" + KEY_FIELDS.key() + "' will work with prefixed names. When constructing the data type of the key format, the prefix will be removed and the non-prefixed names will be used within the key format. Please note that this option requires that '" + VALUE_FIELDS_INCLUDE.key() + "' must be '" + KafkaOptions.ValueFieldsStrategy.EXCEPT_KEY + "'.");
        TOPIC = ConfigOptions.key("topic").stringType().asList().noDefaultValue().withDescription("Topic names from which the table is read. Either 'topic' or 'topic-pattern' must be set for source. Option 'topic' is required for sink.");
        TOPIC_PATTERN = ConfigOptions.key("topic-pattern").stringType().noDefaultValue().withDescription("Optional topic pattern from which the table is read for source. Either 'topic' or 'topic-pattern' must be set.");
        PROPS_BOOTSTRAP_SERVERS = ConfigOptions.key("properties.bootstrap.servers").stringType().noDefaultValue().withDescription("Required Kafka server connection string");
        PROPS_GROUP_ID = ConfigOptions.key("properties.group.id").stringType().noDefaultValue().withDescription("Required consumer group in Kafka consumer, no need for Kafka producer");
        SCAN_STARTUP_MODE = ConfigOptions.key("scan.startup.mode").stringType().defaultValue("group-offsets").withDescription("Optional startup mode for Kafka consumer, valid enumerations are \"earliest-offset\", \"latest-offset\", \"group-offsets\", \"timestamp\"\nor \"specific-offsets\"");
        SCAN_STARTUP_SPECIFIC_OFFSETS = ConfigOptions.key("scan.startup.specific-offsets").stringType().noDefaultValue().withDescription("Optional offsets used in case of \"specific-offsets\" startup mode");
        SCAN_STARTUP_TIMESTAMP_MILLIS = ConfigOptions.key("scan.startup.timestamp-millis").longType().noDefaultValue().withDescription("Optional timestamp used in case of \"timestamp\" startup mode");
        SCAN_TOPIC_PARTITION_DISCOVERY = ConfigOptions.key("scan.topic-partition-discovery.interval").durationType().noDefaultValue().withDescription("Optional interval for consumer to discover dynamically created Kafka partitions periodically.");
        SINK_PARTITIONER = ConfigOptions.key("sink.partitioner").stringType().defaultValue("default").withDescription("Optional output partitioning from Flink's partitions\ninto Kafka's partitions valid enumerations are\n\"default\": (use kafka default partitioner to partition records),\n\"fixed\": (each Flink partition ends up in at most one Kafka partition),\n\"round-robin\": (a Flink partition is distributed to Kafka partitions round-robin when 'key.fields' is not specified.)\n\"custom class name\": (use a custom FlinkKafkaPartitioner subclass)");
        SINK_SEMANTIC = ConfigOptions.key("sink.semantic").stringType().defaultValue("at-least-once").withDescription("Optional semantic when commit. Valid enumerationns are [\"at-least-once\", \"exactly-once\", \"none\"]");
        SCAN_STARTUP_MODE_ENUMS = new HashSet(Arrays.asList("earliest-offset", "latest-offset", "group-offsets", "specific-offsets", "timestamp"));
        SINK_SEMANTIC_ENUMS = new HashSet(Arrays.asList("at-least-once", "exactly-once", "none"));
    }

    public static enum ValueFieldsStrategy {
        ALL,
        EXCEPT_KEY;

        private ValueFieldsStrategy() {
        }
    }

    public static class StartupOptions {
        public StartupMode startupMode;
        public Map<KafkaTopicPartition, Long> specificOffsets;
        public long startupTimestampMillis;

        public StartupOptions() {
        }
    }
}
