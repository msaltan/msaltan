
package com.dtstack.chunjun.converter;

import org.apache.flink.table.data.RowData;

import java.io.Serializable;


public interface ISerializationConverter<T> extends Serializable {


    void serialize(RowData rowData, int pos, T output) throws Exception;
}
