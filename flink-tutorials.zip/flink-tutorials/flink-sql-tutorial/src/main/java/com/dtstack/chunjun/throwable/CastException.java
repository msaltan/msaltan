package com.dtstack.chunjun.throwable;


public class CastException extends ChunJunRuntimeException {

    public CastException(String beforeType, String afterType, String stringValue) {
        super(String.format("%s[%s] can not cast to %s.", beforeType, stringValue, afterType));
    }

    public CastException(String message) {
        super(message);
    }
}
