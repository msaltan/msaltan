
package com.dtstack.chunjun.converter;

import org.apache.flink.table.data.RowData;

import java.io.Serializable;

public interface IDeserializationConverter<T, E> extends Serializable {


    E deserialize(T field) throws Exception;
}
