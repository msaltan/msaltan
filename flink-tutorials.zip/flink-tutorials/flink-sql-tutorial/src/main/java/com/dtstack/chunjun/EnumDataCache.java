//package com.dtstack.chunjun;
//
//import com.dtstack.chunjun.conf.FieldConf;
//
//import com.dtstack.chunjun.lookup.cache.AbstractSideCache;
//
//import com.dtstack.chunjun.lookup.cache.CacheObj;
//import com.dtstack.chunjun.lookup.cache.LRUSideCache;
//
//import com.hazelcast.client.HazelcastClient;
//import com.hazelcast.client.config.ClientConfig;
//import com.hazelcast.core.Hazelcast;
//import com.hazelcast.core.HazelcastInstance;
//import org.apache.kudu.client.RowResult;
//
//import java.util.Map;
//
//public class EnumDataCache {
//    static HazelcastInstance hzInstance;
//    public static void initCache(){
//        synchronized(hzInstance){
//            if(hzInstance==null) {
//                ClientConfig config = new ClientConfig();
//                config.setClusterName("dev");
//                hzInstance  = HazelcastClient.newHazelcastClient(config);
//            }
//        }
//    }
//    public static String GetCachedData(Object valueConverted, int index, FieldConf fieldConf)
//    {
//        if(hzInstance==null) initCache();
//        if (valueConverted == null) return "";
//        String dataFormat = fieldConf.getDataFormat();//.contains("enums:") //.contains("lookup:")
//        if(dataFormat.contains("enums:") || dataFormat.contains("lookup:")) {
//            //String enumKey = dataFormat.substring(6).trim();
//            Map<Object,Object> maps = hzInstance.getMap(dataFormat);
//            if(maps == null) return valueConverted.toString();
//            Object cacRetData=maps.get(valueConverted);
//            if(cacRetData == null) return valueConverted.toString();
//            return cacRetData.toString();
//        }
//
//        return valueConverted.toString();
//    }
//}
