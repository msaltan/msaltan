/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.dtstack.chunjun.connector.kudu.converter;

//--import com.dtstack.chunjun.EnumDataCache;
import com.dtstack.chunjun.conf.FieldConf;
import com.dtstack.chunjun.converter.AbstractRowConverter;
import com.dtstack.chunjun.converter.IDeserializationConverter;
import com.dtstack.chunjun.converter.ISerializationConverter;
import com.dtstack.chunjun.element.AbstractBaseColumn;
import com.dtstack.chunjun.element.ColumnRowData;
import com.dtstack.chunjun.element.column.BigDecimalColumn;
import com.dtstack.chunjun.element.column.BooleanColumn;
import com.dtstack.chunjun.element.column.ByteColumn;
import com.dtstack.chunjun.element.column.BytesColumn;
import com.dtstack.chunjun.element.column.SqlDateColumn;
import com.dtstack.chunjun.element.column.StringColumn;
import com.dtstack.chunjun.element.column.TimestampColumn;
import com.dtstack.chunjun.throwable.UnsupportedTypeException;

import com.ibm.icu.text.MessageFormat;
import org.apache.commons.lang3.StringUtils;

import org.apache.flink.table.data.RowData;
import org.apache.flink.table.types.logical.RowType;

import org.apache.kudu.client.Operation;
import org.apache.kudu.client.RowResult;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * @author tiezhu
 * @since 2021/6/10 星期四
 */
public class KuduColumnConverter
        extends AbstractRowConverter<RowResult, RowResult, Operation, String> {

    private static final long serialVersionUID = 1L;

    private final List<String> columnName;
    private final List<FieldConf> fieldConfList;

    public KuduColumnConverter(RowType rowType, List<String> columnName,List<FieldConf> fieldConfList) {
        super(rowType);
        this.columnName = columnName;
        this.fieldConfList = fieldConfList;
        for (int i = 0; i < rowType.getFieldCount(); i++) {
            toInternalConverters.add(
                    wrapIntoNullableInternalConverter(
                            createInternalConverter(rowType.getTypeAt(i).getTypeRoot().name())));
            toExternalConverters.add(
                    wrapIntoNullableExternalConverter(
                            createExternalConverter(rowType.getTypeAt(i).getTypeRoot().name()),
                            rowType.getTypeAt(i).getTypeRoot().name()));
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    protected ISerializationConverter<Operation> wrapIntoNullableExternalConverter(
            ISerializationConverter serializationConverter, String type) {
        return (val, index, operation) -> {
            if (((ColumnRowData) val).getField(index) == null || val.isNullAt(index)) {
                operation.getRow().setNull(columnName.get(index));
            } else {
                serializationConverter.serialize(val, index, operation);
            }
        };
    }

    @Override
    @SuppressWarnings("unchecked")
    public RowData toInternal(RowResult input) throws Exception {
        //ColumnRowData data = new ColumnRowData(rowType.getFieldCount());
        Map<String,Object> map4DataFormat = new HashMap<>();
        ColumnRowData result = new ColumnRowData(fieldConfList.size());
        for (int i = 0; i < fieldConfList.size(); i++) {
            FieldConf fieldConf = fieldConfList.get(i);
            if (StringUtils.isBlank(fieldConf.getDataFormat())) {

                Object field = input.getObject(fieldConf.getName());
                AbstractBaseColumn baseColumn = ((AbstractBaseColumn) toInternalConverters.get(i).deserialize(field));
                result.addField(assembleFieldProps(fieldConfList.get(i), baseColumn));
                map4DataFormat.put(fieldConf.getName(),baseColumn.getData());
            }
            else {
                if(fieldConf.getDataFormat().contains("now()")) {
                    AbstractBaseColumn baseColumn4 = new TimestampColumn(System.currentTimeMillis());
                    result.addField(baseColumn4);
                }
                /*--else if(fieldConf.getDataFormat().contains("enums:")) {
                    Object value = input.getObject(fieldConf.getName());
                    Object valueConverted = ((AbstractBaseColumn) toInternalConverters.get(i).deserialize(value)).getData();
                    String strCachedData= EnumDataCache.GetCachedData(valueConverted,i,fieldConf );
                    AbstractBaseColumn baseColumn5 = new StringColumn(strCachedData, "");
                    result.addField(baseColumn5);
                }
                else if(fieldConf.getDataFormat().contains("lookup:")) {
                    Object value = input.getObject(fieldConf.getName());
                    Object valueConverted = ((AbstractBaseColumn) toInternalConverters.get(i).deserialize(value)).getData();
                    String strCachedData= EnumDataCache.GetCachedData(valueConverted,i,fieldConf );
                    AbstractBaseColumn baseColumn5 = new StringColumn(strCachedData, "");
                    result.addField(baseColumn5);
                }*/
                else {
                    AbstractBaseColumn baseColumn3 = new StringColumn("", "");
                    result.addField(baseColumn3);
                }
            }
        }
        int converterDataIndex = 0;
        for (FieldConf fieldConf : fieldConfList) {
            if (!StringUtils.isBlank(fieldConf.getDataFormat())
                    && !fieldConf.getDataFormat().contains("now()")
                    && fieldConf.getDataFormat().startsWith("concat:") ){
                String dataString1 = MessageFormat.format(fieldConf.getDataFormat().substring(7), map4DataFormat);
                AbstractBaseColumn baseColumn = new StringColumn(dataString1, "");
                result.setField(converterDataIndex,baseColumn);
            }
            converterDataIndex++;
        }
        /*for (int pos = 0; pos < rowType.getFieldCount(); pos++) {
            Object field = input.getObject(pos);
            data.addField((AbstractBaseColumn) toInternalConverters.get(pos).deserialize(field));
        }*/
        return result;
    }

    @Override
    @SuppressWarnings("unchecked")
    public Operation toExternal(RowData rowData, Operation operation) throws Exception {
        for (int index = 0; index < rowData.getArity(); index++) {
            toExternalConverters.get(index).serialize(rowData, index, operation);
        }
        return operation;
    }

    @Override
    protected IDeserializationConverter createInternalConverter(String type) {
        switch (type.toUpperCase(Locale.ENGLISH)) {
            case "BOOL":
            case "BOOLEAN":
                return val -> new BooleanColumn(Boolean.parseBoolean(val.toString()));
            case "INT8":
            case "TINYINT":
                return val -> new ByteColumn((byte) val);
            case "INT16":
            case "SMALLINT":
                return val -> new BigDecimalColumn((Short) val);
            case "INTEGER":
            case "INT32":
            case "INT":
                return val -> new BigDecimalColumn((Integer) val);
            case "FLOAT":
                return val -> new BigDecimalColumn((Float) val);
            case "DOUBLE":
                return val -> new BigDecimalColumn((Double) val);
            case "LONG":
            case "INT64":
            case "BIGINT":
                return val -> new BigDecimalColumn((Long) val);
            case "DECIMAL":
                return val -> new BigDecimalColumn((BigDecimal) val);
            case "VARCHAR":
            case "STRING":
                return val -> new StringColumn((String) val);
            case "DATE":
                return val -> new SqlDateColumn(Date.valueOf(String.valueOf(val)));
            case "TIMESTAMP":
            case "TIMESTAMP_WITHOUT_TIME_ZONE":
                return val -> new TimestampColumn((Timestamp) val);
            case "BINARY":
                return val -> new BytesColumn((byte[]) val);
            default:
                throw new UnsupportedOperationException("Unsupported type:" + type);
        }
    }

    @Override
    protected ISerializationConverter<Operation> createExternalConverter(String type) {
        switch (type.toUpperCase(Locale.ENGLISH)) {
            case "BOOLEAN":
            case "BOOL":
                return (val, index, operation) ->
                        operation.getRow().addBoolean(columnName.get(index), val.getBoolean(index));
            case "TINYINT":
            case "CHAR":
            case "INT8":
                return (val, index, operation) ->
                        operation.getRow().addByte(columnName.get(index), val.getByte(index));
            case "INT16":
            case "SMALLINT":
                return (val, index, operation) ->
                        operation.getRow().addShort(columnName.get(index), val.getShort(index));
            case "INTEGER":
            case "INT":
            case "INT32":
                return (val, index, operation) ->
                        operation.getRow().addInt(columnName.get(index), val.getInt(index));
            case "BIGINT":
            case "INT64":
                return (val, index, operator) ->
                        operator.getRow().addLong(columnName.get(index), val.getLong(index));
            case "FLOAT":
                return (val, index, operation) ->
                        operation.getRow().addFloat(columnName.get(index), val.getFloat(index));
            case "DOUBLE":
                return (val, index, operation) ->
                        operation.getRow().addDouble(columnName.get(index), val.getDouble(index));
            case "BINARY":
                return (val, index, operation) ->
                        operation.getRow().addBinary(columnName.get(index), val.getBinary(index));
            case "DECIMAL":
                return (val, index, operation) ->
                        operation
                                .getRow()
                                .addDecimal(
                                        columnName.get(index),
                                        ((ColumnRowData) val).getField(index).asBigDecimal());
            case "VARCHAR":
                return (val, index, operation) ->
                        operation
                                .getRow()
                                .addString(columnName.get(index), val.getString(index).toString());
            case "DATE":
                return (val, index, operation) ->
                        operation
                                .getRow()
                                .addDate(
                                        columnName.get(index),
                                        ((ColumnRowData) val).getField(index).asSqlDate());

            case "TIMESTAMP":
            case "TIMESTAMP_WITHOUT_TIME_ZONE":
                return (val, index, operation) ->
                        operation
                                .getRow()
                                .addTimestamp(
                                        columnName.get(index),
                                        ((ColumnRowData) val).getField(index).asTimestamp());
            default:
                throw new UnsupportedTypeException(type);
        }
    }
}
