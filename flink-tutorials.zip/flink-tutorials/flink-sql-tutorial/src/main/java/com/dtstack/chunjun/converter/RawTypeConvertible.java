
package com.dtstack.chunjun.converter;


public interface RawTypeConvertible {

    String NO_SUPPORT_MSG = " connector don't support to set raw type.";

    RawTypeConverter getRawTypeConverter();
}
