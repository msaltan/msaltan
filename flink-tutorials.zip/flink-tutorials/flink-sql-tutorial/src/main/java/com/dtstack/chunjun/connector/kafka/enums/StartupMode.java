
package com.dtstack.chunjun.connector.kafka.enums;

import org.apache.commons.lang3.StringUtils;

import java.util.Locale;


public enum StartupMode {

    /**
     * Start from committed offsets in ZK / Kafka brokers of a specific consumer group (default).
     */
    GROUP_OFFSETS("group-offsets"),
    /** Start from the earliest offset possible. */
    EARLIEST("earliest-offset"),
    /** Start from the latest offset. */
    LATEST("latest-offset"),
    /** Start from user-supplied timestamp for each partition. */
    TIMESTAMP("timestamp"),
    /** Start from user-supplied specific offsets for each partition */
    SPECIFIC_OFFSETS("specific-offsets"),

    UNKNOWN("unknown");

    public String name;

    StartupMode(String name) {
        this.name = name;
    }

    /**
     * 根据名称获取启动模式
     *
     * @param name
     * @return
     */
    public static StartupMode getFromName(String name) {
        if (StringUtils.isBlank(name)) {
            throw new IllegalArgumentException("StartupMode name is blank.");
        }
        switch (name.toLowerCase(Locale.ENGLISH)) {
            case "earliest-offset":
                return EARLIEST;
            case "latest-offset":
                return LATEST;
            case "timestamp":
                return TIMESTAMP;
            case "specific-offsets":
                return SPECIFIC_OFFSETS;
            case "group-offsets":
                return GROUP_OFFSETS;
            default:
                return UNKNOWN;
        }
    }
}
