
package com.dtstack.chunjun.converter;

import org.apache.flink.table.types.DataType;


@FunctionalInterface
public interface RawTypeConverter {

    DataType apply(String type);
}
