package com.dtstack.chunjun.conf;

public class NameMappingConf {
}
