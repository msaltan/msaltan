
package com.dtstack.chunjun.throwable;


public class WriteRecordException extends Exception {

    private final int colIndex;
    private final Object rowData;

    public WriteRecordException(String message, Throwable cause, int colIndex, Object rowData) {
        super(message, cause);
        this.colIndex = colIndex;
        this.rowData = rowData;
    }

    public int getColIndex() {
        return colIndex;
    }

    public Object getRowData() {
        return rowData;
    }

    public WriteRecordException(String message, Throwable cause) {
        this(message, cause, -1, null);
    }

    @Override
    public String toString() {
        return super.toString() + "\n" + getCause().toString();
    }
}
