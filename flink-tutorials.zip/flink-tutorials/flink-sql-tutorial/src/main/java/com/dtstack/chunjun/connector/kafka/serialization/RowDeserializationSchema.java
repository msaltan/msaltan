package com.dtstack.chunjun.connector.kafka.serialization;



import com.dtstack.chunjun.connector.kafka.conf.KafkaConf;
import com.dtstack.chunjun.connector.kafka.source.DynamicKafkaDeserializationSchema;
import com.dtstack.chunjun.converter.AbstractRowConverter;
import com.dtstack.chunjun.util.JsonUtil;

import org.apache.flink.api.common.serialization.DeserializationSchema;
import org.apache.flink.table.data.RowData;
import org.apache.flink.util.Collector;

import org.apache.kafka.clients.consumer.ConsumerRecord;

import java.nio.charset.StandardCharsets;

/**
 * Date: 2021/03/04 Company: www.dtstack.com
 *
 * @author tudou
 */
public class RowDeserializationSchema extends DynamicKafkaDeserializationSchema {

    private static final long serialVersionUID = 1L;
    /** kafka converter */
    private final AbstractRowConverter<String, Object, byte[], String> converter;
    /** kafka conf */
    private final KafkaConf kafkaConf;

    public RowDeserializationSchema(
            KafkaConf kafkaConf, AbstractRowConverter<String, Object, byte[], String> converter) {
        super(1, null, null, null, null, false, null, null, false);
        this.kafkaConf = kafkaConf;
        this.converter = converter;
    }

    @Override
    public void open(DeserializationSchema.InitializationContext context) {
        beforeOpen();
        LOG.info(
                "[{}] open successfully, \ninputSplit = {}, \n[{}]: \n{} ",
                this.getClass().getSimpleName(),
                "see other log",
                kafkaConf.getClass().getSimpleName(),
                JsonUtil.toPrintJson(kafkaConf));
    }

    @Override
    public void deserialize(ConsumerRecord<byte[], byte[]> record, Collector<RowData> collector) {
        try {
            beforeDeserialize(record);
            collector.collect(
                    converter.toInternal(new String(record.value(), StandardCharsets.UTF_8)));
        } catch (Exception e) {
            //dirtyManager.collect(new String(record.value(), StandardCharsets.UTF_8), e, null);
        }
    }
}
