# Flink Quickstart Skeleton

This is a maven skeleton project for Flink on Cloudera.
Its content is identical with the project [flink-quickstart-archetype](../flink-quickstart-archetype) generates.  
